package cn.suse.edu.schoolserver.common.redis;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import redis.clients.jedis.Jedis;

@Configuration
public class RedisLoginClusterConfig {
	@Value("${spring.redis.host:null}")
	private String host;
	@Value("${spring.redis.port:6379}")
	private Integer port;

	@Bean
	public Jedis getJedis() {

		Jedis jedis = new Jedis(host, port);
		jedis.auth("redis6380");
		return jedis;

	}
}
