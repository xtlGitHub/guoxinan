package cn.suse.edu.schoolserver.common.redis;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import redis.clients.jedis.Jedis;
import redis.clients.jedis.ShardedJedis;

@Service
public class RedisLoginService {
	@Autowired(required = false)
	private Jedis jedis;

	public void set(String key, String value) {
		// ShardedJedis jedis = pool.getResource();
		//System.out.println("kaishi 了");
		jedis = new Jedis("47.106.125.51",6380);
		
		jedis.set(key, value);
		//System.out.println("结束了了");
		// pool.returnResource(jedis);
	}

	public void set(String key, String value, Integer seconds) {
		// ShardedJedis jedis = pool.getResource();
		
		jedis.set(key, value);
		jedis.expire(key, seconds);
		// pool.returnResource(jedis);
	}
	
	public Boolean exists(String key){
		//ShardedJedis jedis = pool.getResource();
		Boolean exists = jedis.exists(key);
		
		return exists;
	}
	public String get(String key){
		//ShardedJedis jedis = pool.getResource();
		String value = jedis.get(key);
		//pool.returnResource(jedis);
		return value;
	}
	public void del(String key){
		//ShardedJedis jedis = pool.getResource();
		jedis.del(key);
		//pool.returnResource(jedis);
	}
}
