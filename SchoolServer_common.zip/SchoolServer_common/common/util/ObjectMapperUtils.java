package cn.suse.edu.schoolserver.common.util;

import com.fasterxml.jackson.databind.ObjectMapper;

public class ObjectMapperUtils {
	public static final ObjectMapper mapper=new ObjectMapper();
	
	public static ObjectMapper getMapper(){
		return mapper;
	}
}
