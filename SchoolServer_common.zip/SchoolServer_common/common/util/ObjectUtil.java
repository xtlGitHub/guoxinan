package cn.suse.edu.schoolserver.common.util;

import com.fasterxml.jackson.databind.ObjectMapper;

public class ObjectUtil {
	public static final ObjectMapper mapper=new ObjectMapper();

}
